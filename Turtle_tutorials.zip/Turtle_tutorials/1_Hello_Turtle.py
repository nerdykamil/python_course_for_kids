# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 14:47:55 2023

@author: Yusra Shahid
"""

import turtle

s = turtle.getscreen()

t = turtle.Turtle()

t.forward(100)
t.right(90)
t.backward(100)
t.left(90)

t.goto(100,100)


turtle.bye()
