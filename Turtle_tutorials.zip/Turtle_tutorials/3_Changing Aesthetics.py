# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 10:58:29 2023

@author: Yusra Shahid
"""

import turtle

s= turtle.getscreen()

## change background color
turtle.bgcolor('blue')

turtle.title("My Turtle Program")

## change turtle looks

t = turtle.Turtle()

t.pensize(5)

t.shape("turtle")

## close screen

turtle.bye()
